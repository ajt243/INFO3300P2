### Unique Fast Food Names

1. Chick-Fil-A
2. Chipotle
3. Dominos
4. Little Caesars
5. McDonald's
6. Papa John's
7. Pizza Hut
8. Starbucks
9. Taco Bell


**Note:* some are duplicated and spelled differently

ex: McDonalds and McDonald's